from datetime import datetime, timedelta
import random
from src.utils.mongodb_client import get_mongodb_client

# OPTIONAL (Twilio / Email later)
# from src.utils.otp_service import send_sms_otp, send_email_otp

db = get_mongodb_client()


# Generate 6-digit OTP
def generate_otp():
    return str(random.randint(100000, 999999))


# Send OTP (for now prints in terminal)
def send_otp(phone=None, email=None):

    otp = generate_otp()

    print("Generated OTP:", otp)   # Demo purpose

    record = {
        "phone": phone,
        "email": email,
        "otp": otp,
        "created_at": datetime.utcnow(),
        "verified": False
    }

    db.insert_one("otp_codes", record)

    return otp


def verify_otp(phone=None, email=None, otp=None):

    query = {"otp": otp}

    if phone:
        query["phone"] = phone

    if email:
        query["email"] = email

    record = db.find_one("otp_codes", query)

    if not record:
        return False

    # OTP expiration check (5 minutes)
    if datetime.utcnow() - record["created_at"] > timedelta(minutes=5):
        return False

    db.update_one(
        "otp_codes",
        {"_id": record["_id"]},
        {"verified": True}
    )

    return True