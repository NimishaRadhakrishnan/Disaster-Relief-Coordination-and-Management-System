from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

class ModernLogin(QWidget):

    login_success = pyqtSignal(dict)

    def __init__(self):
        super().__init__()

        self.setMinimumSize(1200,700)

        main_layout = QHBoxLayout(self)

        # LEFT PANEL
        left = QFrame()
        left.setStyleSheet("background-color:#0b1e30;color:white;")
        left_layout = QVBoxLayout(left)
        left_layout.setAlignment(Qt.AlignCenter)

        logo = QLabel("⚠")
        logo.setFont(QFont("Arial",70))
        logo.setAlignment(Qt.AlignCenter)

        title = QLabel("DisasterConnect")
        title.setFont(QFont("Arial",32,QFont.Bold))
        title.setAlignment(Qt.AlignCenter)

        subtitle = QLabel("EMERGENCY RESPONSE PLATFORM")
        subtitle.setStyleSheet("color:#9bb4c7;font-size:14px;")
        subtitle.setAlignment(Qt.AlignCenter)

        stats = QLabel("24/7 Monitoring    150+ Agencies    99.9% Uptime")
        stats.setAlignment(Qt.AlignCenter)

        left_layout.addWidget(logo)
        left_layout.addWidget(title)
        left_layout.addWidget(subtitle)
        left_layout.addSpacing(40)
        left_layout.addWidget(stats)

        # RIGHT PANEL
        right = QFrame()
        right_layout = QVBoxLayout(right)
        right_layout.setAlignment(Qt.AlignCenter)

        heading = QLabel("Sign in to your account")
        heading.setFont(QFont("Arial",28,QFont.Bold))

        desc = QLabel(
            "Coordinate disaster response and manage resources in real-time."
        )
        desc.setStyleSheet("color:gray;")

        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")

        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.Password)

        login_btn = QPushButton("LOGIN →")
        login_btn.setFixedHeight(45)

        login_btn.clicked.connect(self.login)

        right_layout.addWidget(heading)
        right_layout.addWidget(desc)
        right_layout.addSpacing(20)
        right_layout.addWidget(self.username)
        right_layout.addWidget(self.password)
        right_layout.addSpacing(10)
        right_layout.addWidget(login_btn)

        main_layout.addWidget(left,1)
        main_layout.addWidget(right,1)

    def login(self):

        username = self.username.text()

        if username == "":
            return

        self.login_success.emit({"username":username})