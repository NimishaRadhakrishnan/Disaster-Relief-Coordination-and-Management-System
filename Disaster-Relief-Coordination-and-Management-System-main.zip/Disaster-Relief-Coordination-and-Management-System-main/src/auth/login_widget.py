from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel,
    QLineEdit, QPushButton, QMessageBox, QFrame
)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QPixmap
from ..utils.mongodb_client import mongodb_client
import hashlib
import logging
import os

logger = logging.getLogger(__name__)


class LoginWidget(QWidget):

    login_success = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):

        # MAIN LAYOUT
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignCenter)

        # LOGIN CARD
        card = QFrame()
        card.setObjectName("loginCard")
        card.setFixedWidth(350)

        layout = QVBoxLayout(card)
        layout.setSpacing(15)

        # LOGO
        logo_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            "resources",
            "images",
            "logo_new.svg"
        )

        if os.path.exists(logo_path):
            logo_label = QLabel()
            pixmap = QPixmap(logo_path)
            pixmap = pixmap.scaled(90, 90, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_label.setPixmap(pixmap)
            logo_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(logo_label)

        # TITLE
        title = QLabel("DisasterConnect")
        title.setObjectName("loginTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # USERNAME
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        layout.addWidget(self.username_input)

        # PASSWORD
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)

        # LOGIN BUTTON
        self.login_button = QPushButton("Login")
        self.login_button.setObjectName("loginButton")
        self.login_button.clicked.connect(self.handle_login)
        layout.addWidget(self.login_button)

        main_layout.addWidget(card)
        self.setLayout(main_layout)

    def handle_login(self):

        try:

            username = self.username_input.text().strip()
            password = self.password_input.text().strip()

            if not username or not password:
                QMessageBox.warning(self, "Error", "Enter username and password")
                return

            hashed_password = hashlib.sha256(password.encode()).hexdigest()

            db = mongodb_client.db

            user = db.users.find_one({
                "username": username,
                "password": hashed_password
            })

            if user:

                user["_id"] = str(user["_id"])
                user.pop("password", None)

                self.login_success.emit(user)

            else:

                QMessageBox.warning(self, "Error", "Invalid username or password")

        except Exception as e:

            logger.error(str(e))
            QMessageBox.critical(self, "Error", str(e))

    def clear_fields(self):

        self.username_input.clear()
        self.password_input.clear()