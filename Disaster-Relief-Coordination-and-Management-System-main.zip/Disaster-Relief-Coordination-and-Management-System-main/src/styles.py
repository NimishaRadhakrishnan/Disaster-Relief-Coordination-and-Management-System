self.setStyleSheet("""
#sidebar {
    background-color: #0b1e30;
}

#sidebarTitle {
    color: white;
    font-size: 20px;
    font-weight: bold;
}

#sidebarButton {
    background: transparent;
    color: white;
    padding: 12px;
    text-align: left;
    border: none;
}

#sidebarButton:hover {
    background-color: #1f3b5b;
}

#logoutButton {
    background-color: #d9534f;
    color: white;
    padding: 10px;
}

#pageTitle {
    font-size: 22px;
    font-weight: bold;
}
""")