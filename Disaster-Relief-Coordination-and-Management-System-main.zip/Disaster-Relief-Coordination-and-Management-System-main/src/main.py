"""
Main entry point for DisasterConnect application
Modernized UI version
"""

import sys
import os
from dotenv import load_dotenv

from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QStackedWidget
)

from PyQt5.QtCore import QTimer, QPropertyAnimation
from PyQt5.QtGui import QIcon

from src.auth.auth_manager import AuthManager
from src.auth.modern_login import ModernLogin
from src.dashboard.dashboard_window import DashboardWindow
from src.widgets.splash_screen import SplashScreen
from src.styles import get_app_stylesheet


# Load environment variables
load_dotenv()


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("DisasterConnect")
        self.setMinimumSize(1280, 820)

        self.center_window()

        # Application icon
        icon_path = os.path.join(
            os.path.dirname(__file__),
            "resources",
            "images",
            "logo_icon.png"
        )

        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        # Authentication manager
        self.auth_manager = AuthManager()

        # Central widget
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        # Layout
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(0, 0, 0, 0)

        # Page container
        self.stacked_widget = QStackedWidget()
        self.layout.addWidget(self.stacked_widget)

        self.setup_ui()

    def center_window(self):
        """Center window on screen"""
        screen = QApplication.primaryScreen().geometry()

        width = 1280
        height = 820

        x = (screen.width() - width) // 2
        y = (screen.height() - height) // 2

        self.setGeometry(x, y, width, height)

    def setup_ui(self):
        """Create login and dashboard pages"""

        # LOGIN PAGE
        self.login_window = ModernLogin()

        # Connect login success signal
        self.login_window.login_success.connect(self.on_login_successful)

        # DASHBOARD PAGE
        self.dashboard_window = DashboardWindow(
            auth_manager=self.auth_manager
        )

        # Add pages to stack
        self.stacked_widget.addWidget(self.login_window)
        self.stacked_widget.addWidget(self.dashboard_window)

        # Start with login
        self.stacked_widget.setCurrentWidget(self.login_window)

    def on_login_successful(self, user_data):
        """Switch to dashboard after login"""

        self.stacked_widget.setCurrentWidget(self.dashboard_window)

        # Smooth fade animation
        self.fade = QPropertyAnimation(
            self.dashboard_window,
            b"windowOpacity"
        )

        self.fade.setDuration(500)
        self.fade.setStartValue(0)
        self.fade.setEndValue(1)
        self.fade.start()

        # Maximize window
        self.showMaximized()

        username = user_data.get("username", "User")

        self.setWindowTitle(
            f"DisasterConnect | Dashboard | {username}"
        )


def main():

    # Enable high DPI scaling
    os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

    app = QApplication(sys.argv)

    app.setStyle("Fusion")

    # Apply stylesheet
    app.setStyleSheet(get_app_stylesheet())

    # App icon
    icon_path = os.path.join(
        os.path.dirname(__file__),
        "resources",
        "images",
        "logo_icon.png"
    )

    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    # Splash screen
    splash = SplashScreen()
    splash.show()

    app.processEvents()

    # Create main window
    window = MainWindow()

    def start_app():
        splash.finish(window)
        window.show()

    # Splash delay
    QTimer.singleShot(2000, start_app)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()