"""Modern Splash screen for DisasterConnect."""

from PyQt5.QtWidgets import (
    QSplashScreen,
    QLabel,
    QVBoxLayout,
    QWidget,
    QProgressBar
)

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap
import os


class SplashScreen(QSplashScreen):

    def __init__(self):

        splash_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            "resources",
            "images",
            "logo_splash.png"
        )

        pixmap = QPixmap(splash_path)

        super().__init__(pixmap)

        self.setWindowFlags(
            Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint
        )

        self.setMask(pixmap.mask())

        # MAIN CONTAINER
        container = QWidget(self)
        container.setGeometry(0, 0, pixmap.width(), pixmap.height())

        layout = QVBoxLayout(container)
        layout.setAlignment(Qt.AlignCenter)

        layout.addStretch()

        # APP TITLE
        self.title = QLabel("DisasterConnect")
        self.title.setStyleSheet("""
            QLabel{
                color:#2c3e50;
                font-size:30px;
                font-weight:bold;
            }
        """)
        self.title.setAlignment(Qt.AlignCenter)

        layout.addWidget(self.title)

        # SUBTITLE
        self.subtitle = QLabel("Disaster Management Platform")
        self.subtitle.setStyleSheet("""
            QLabel{
                color:#7f8c8d;
                font-size:16px;
            }
        """)
        self.subtitle.setAlignment(Qt.AlignCenter)

        layout.addWidget(self.subtitle)

        layout.addSpacing(20)

        # LOADING TEXT
        self.loading_label = QLabel("Initializing application...")
        self.loading_label.setAlignment(Qt.AlignCenter)

        self.loading_label.setStyleSheet("""
            QLabel{
                color:#34495e;
                font-size:14px;
            }
        """)

        layout.addWidget(self.loading_label)

        # PROGRESS BAR
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedWidth(300)
        self.progress_bar.setMaximum(100)

        self.progress_bar.setStyleSheet("""
            QProgressBar{
                border:1px solid #ccc;
                border-radius:6px;
                text-align:center;
                height:14px;
            }

            QProgressBar::chunk{
                background-color:#3498db;
                border-radius:6px;
            }
        """)

        layout.addWidget(self.progress_bar)

        layout.addStretch()

        # PROGRESS STATE
        self.progress = 0

        self.progress_texts = [
            "Initializing application...",
            "Loading modules...",
            "Connecting database...",
            "Preparing dashboard...",
            "Starting DisasterConnect..."
        ]

        # TIMER
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_progress)
        self.timer.start(600)

    def update_progress(self):

        self.progress += 20

        self.progress_bar.setValue(self.progress)

        index = min(
            int(self.progress / 20),
            len(self.progress_texts) - 1
        )

        self.loading_label.setText(
            self.progress_texts[index]
        )

        if self.progress >= 100:
            self.timer.stop()