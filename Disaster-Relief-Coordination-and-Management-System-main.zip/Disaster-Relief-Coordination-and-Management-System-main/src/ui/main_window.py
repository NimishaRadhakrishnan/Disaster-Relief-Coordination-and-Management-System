from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QStackedWidget, QLabel, QFrame
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
import os

from ..dashboard.dashboard_widget import DashboardWidget
from ..incidents.incidents_widget import IncidentsWidget
from ..resources.resources_widget import ResourcesWidget
from ..auth.login_widget import LoginWidget


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("DisasterConnect")
        self.setMinimumSize(1200, 800)

        icon_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "resources", "images", "logo_new.svg"
        )

        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        # CENTRAL CONTAINER
        container = QWidget()
        self.setCentralWidget(container)

        self.layout = QVBoxLayout(container)
        self.layout.setContentsMargins(0, 0, 0, 0)

        # LOGIN SCREEN
        self.login_widget = LoginWidget(self)
        self.login_widget.login_success.connect(self.on_login_success)

        self.layout.addWidget(self.login_widget)

        # DASHBOARD CONTAINER
        self.dashboard_container = QWidget()
        self.dashboard_container.hide()

        self.layout.addWidget(self.dashboard_container)

        self.setup_dashboard()

    # ---------------- DASHBOARD ----------------

    def setup_dashboard(self):

        main_layout = QHBoxLayout(self.dashboard_container)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # ---------------- SIDEBAR ----------------
        sidebar = QVBoxLayout()

        logo = QLabel("DisasterConnect")
        logo.setAlignment(Qt.AlignCenter)
        logo.setObjectName("sidebarTitle")

        sidebar.addWidget(logo)
        sidebar.addSpacing(20)

        self.dashboard_btn = QPushButton("Dashboard")
        self.incidents_btn = QPushButton("Incidents")
        self.resources_btn = QPushButton("Resources")

        for btn in [self.dashboard_btn, self.incidents_btn, self.resources_btn]:
            btn.setObjectName("sidebarButton")
            sidebar.addWidget(btn)

        sidebar.addStretch()

        self.logout_button = QPushButton("Logout")
        self.logout_button.setObjectName("logoutButton")

        sidebar.addWidget(self.logout_button)

        sidebar_frame = QFrame()
        sidebar_frame.setObjectName("sidebar")
        sidebar_frame.setLayout(sidebar)
        sidebar_frame.setFixedWidth(240)

        main_layout.addWidget(sidebar_frame)

        # ---------------- CONTENT AREA ----------------

        content_layout = QVBoxLayout()

        # HEADER
        header = QHBoxLayout()

        title = QLabel("Dashboard")
        title.setObjectName("pageTitle")

        header.addWidget(title)
        header.addStretch()

        content_layout.addLayout(header)

        # STACKED PAGES
        self.stack = QStackedWidget()

        self.dashboard = DashboardWidget()
        self.incidents = IncidentsWidget()
        self.resources = ResourcesWidget()

        self.stack.addWidget(self.dashboard)
        self.stack.addWidget(self.incidents)
        self.stack.addWidget(self.resources)

        content_layout.addWidget(self.stack)

        content_widget = QWidget()
        content_widget.setLayout(content_layout)

        main_layout.addWidget(content_widget)

        # ---------------- BUTTON ACTIONS ----------------

        self.dashboard_btn.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.dashboard)
        )

        self.incidents_btn.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.incidents)
        )

        self.resources_btn.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.resources)
        )

        self.logout_button.clicked.connect(self.logout)

    # ---------------- LOGIN SUCCESS ----------------

    def on_login_success(self, user_data):

        self.login_widget.hide()
        self.dashboard_container.show()

        self.showMaximized()

        username = user_data.get("username")

        self.setWindowTitle(f"DisasterConnect — Welcome {username}")

        self.dashboard.refresh_data()
        self.incidents.refresh_data()
        self.resources.refresh_table()

    # ---------------- LOGOUT ----------------

    def logout(self):

        self.dashboard_container.hide()
        self.login_widget.show()
        self.login_widget.clear_fields()

        self.setWindowTitle("DisasterConnect")