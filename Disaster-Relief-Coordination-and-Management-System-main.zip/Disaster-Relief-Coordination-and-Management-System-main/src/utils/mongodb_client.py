content = """import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure


class MongoDBClient:
    _instance = None
    _client = None
    _db = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(MongoDBClient, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, "initialized"):
            self.initialized = False

    def initialize_connection(self):
        if self._client is not None:
            return
        uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
        db_name = os.getenv("MONGODB_DATABASE", "disasterconnect")
        self._client = MongoClient(uri)
        self._client.admin.command("ping")
        self._db = self._client[db_name]
        self.initialized = True

    def get_database(self):
        if self._client is None or self._db is None:
            self.initialize_connection()
        return self._db

    def get_collection(self, name):
        if not self._db:
            self.initialize_connection()
        return self._db[name]

    def close_connection(self):
        if self._client:
            self._client.close()
            self._client = None
            self._db = None

    def find_one(self, col, query):
        return self.get_collection(col).find_one(query)

    def insert_one(self, col, doc):
        return str(self.get_collection(col).insert_one(doc).inserted_id)

    def update_one(self, col, query, update):
        return self.get_collection(col).update_one(query, {"$set": update}).modified_count

    @property
    def db(self):
        return self.get_database()


mongodb_client = MongoDBClient()
"""

with open("src/utils/mongodb_client.py", "w") as f:
    f.write(content)

print("Done! File written successfully.")

