import hashlib
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

def hash_password(plain: str) -> str:
    return hashlib.sha256(plain.encode()).hexdigest()

def verify_password(plain: str, hashed: str) -> bool:
    return hash_password(plain) == hashed

class AuthManager:
    def __init__(self, db):
        self.db = db

    def create_user(self, username, password, email, role="responder", created_by="system"):
        if self.db.users.find_one({"username": username}):
            raise ValueError(f"Username '{username}' already exists.")
        doc = {
            "username":   username,
            "password":   hash_password(password),
            "email":      email,
            "role":       role,
            "is_active":  True,
            "created_at": datetime.utcnow().isoformat(),
            "created_by": created_by,
            "last_login": None,
        }
        self.db.users.insert_one(doc)
        logger.info("Created user '%s' (%s)", username, role)
        return {k: v for k, v in doc.items() if k != "password"}

    def login(self, username, password, role):
        user = self.db.users.find_one({"username": username})
        if not user or not verify_password(password, user.get("password", "")):
            raise ValueError("Invalid username or password.")
        user_role = user.get("role", "responder")
        if user_role != "admin" and user_role != role:
            raise ValueError(f"Your account role is '{user_role}'. Please select the correct role tab.")
        if not user.get("is_active", True):
            raise ValueError("This account has been deactivated.")
        self.db.users.update_one({"_id": user["_id"]}, {"$set": {"last_login": datetime.utcnow().isoformat()}})
        return {k: v for k, v in user.items() if k != "password"}