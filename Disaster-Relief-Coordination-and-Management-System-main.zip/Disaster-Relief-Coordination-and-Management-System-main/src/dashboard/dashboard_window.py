from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

from ..dashboard.dashboard_widget import DashboardWidget
from ..incidents.incidents_widget import IncidentsWidget
from ..resources.resources_widget import ResourcesWidget


class DashboardWindow(QWidget):

    def __init__(self, auth_manager=None):
        super().__init__()

        layout = QHBoxLayout(self)

        # SIDEBAR
        sidebar = QVBoxLayout()

        title = QLabel("DisasterConnect")
        title.setStyleSheet("font-size:20px;font-weight:bold;")

        btn_dashboard = QPushButton("Dashboard")
        btn_incidents = QPushButton("Incidents")
        btn_resources = QPushButton("Resources")

        sidebar.addWidget(title)
        sidebar.addSpacing(20)
        sidebar.addWidget(btn_dashboard)
        sidebar.addWidget(btn_incidents)
        sidebar.addWidget(btn_resources)
        sidebar.addStretch()

        sidebar_widget = QWidget()
        sidebar_widget.setLayout(sidebar)
        sidebar_widget.setFixedWidth(220)
        sidebar_widget.setStyleSheet("background:#0b1e30;color:white;")

        # CONTENT AREA
        self.stack = QStackedWidget()

        self.dashboard_page = DashboardWidget()
        self.incidents_page = IncidentsWidget()
        self.resources_page = ResourcesWidget()

        self.stack.addWidget(self.dashboard_page)
        self.stack.addWidget(self.incidents_page)
        self.stack.addWidget(self.resources_page)

        btn_dashboard.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.dashboard_page)
        )

        btn_incidents.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.incidents_page)
        )

        btn_resources.clicked.connect(
            lambda: self.stack.setCurrentWidget(self.resources_page)
        )

        layout.addWidget(sidebar_widget)
        layout.addWidget(self.stack)