from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout


class DashboardWidget(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("Dashboard")
        title.setStyleSheet("font-size:24px; font-weight:bold;")

        layout.addWidget(title)

        self.setLayout(layout)

    def refresh_data(self):
        pass