from src.utils.mongodb_client import get_mongodb_client
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QTableWidget, QTableWidgetItem, QDialog, QFormLayout,
    QLineEdit, QMessageBox, QHeaderView
)
from PyQt5.QtCore import Qt
from datetime import datetime


# ------------------ DIALOG ------------------
class VolunteerDialog(QDialog):

    def __init__(self, parent=None, data=None):
        super().__init__(parent)
        self.data = data
        self.setWindowTitle("Volunteer")
        layout = QFormLayout(self)

        self.name = QLineEdit()
        self.phone = QLineEdit()
        self.skill = QLineEdit()

        if data:
            self.name.setText(data.get("name",""))
            self.phone.setText(data.get("phone",""))
            self.skill.setText(data.get("skill",""))

        layout.addRow("Name", self.name)
        layout.addRow("Phone", self.phone)
        layout.addRow("Skill", self.skill)

        btn = QPushButton("Save")
        btn.clicked.connect(self.accept)
        layout.addWidget(btn)

    def get_data(self):

        data = {
            "name": self.name.text(),
            "phone": self.phone.text(),
            "skill": self.skill.text(),
            "timestamp": datetime.now().isoformat()
        }

        if self.data and "_id" in self.data:
            data["_id"] = self.data["_id"]

        return data


# ------------------ WIDGET ------------------
class VolunteerWidget(QWidget):

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)

        title = QLabel("Volunteer Management")
        layout.addWidget(title)

        add = QPushButton("Add Volunteer")
        add.clicked.connect(self.add_volunteer)
        layout.addWidget(add)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(
            ["Name","Phone","Skill","Actions"]
        )

        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        layout.addWidget(self.table)

        self.load()


    # ---------- ADD ----------
    def add_volunteer(self, data=None):

        dialog = VolunteerDialog(self,data)

        if dialog.exec_()==QDialog.Accepted:
            v = dialog.get_data()
            client = get_mongodb_client()

            if "_id" in v:
                _id=v.pop("_id")
                client.update_one("volunteers",{"_id":_id},v)
            else:
                client.insert_one("volunteers",v)

            self.load()


    # ---------- LOAD ----------
    def load(self):

        client=get_mongodb_client()
        data=client.find_many("volunteers",{})

        self.table.setRowCount(0)

        for d in data:

            r=self.table.rowCount()
            self.table.insertRow(r)

            item=QTableWidgetItem(d["name"])
            item.setData(Qt.UserRole,d["_id"])

            self.table.setItem(r,0,item)
            self.table.setItem(r,1,QTableWidgetItem(d["phone"]))
            self.table.setItem(r,2,QTableWidgetItem(d["skill"]))

            btn=QPushButton("Delete")
            btn.clicked.connect(lambda _,row=r:self.delete(row))

            self.table.setCellWidget(r,3,btn)


    # ---------- DELETE ----------
    def delete(self,row):

        _id=self.table.item(row,0).data(Qt.UserRole)
        client=get_mongodb_client()
        client.delete_one("volunteers",{"_id":_id})
        self.load()